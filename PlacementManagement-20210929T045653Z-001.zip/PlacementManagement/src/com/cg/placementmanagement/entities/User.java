package com.cg.placementmanagement.entities;

public class User {
private long id;
private String name;
private String type;
private String password;

}
