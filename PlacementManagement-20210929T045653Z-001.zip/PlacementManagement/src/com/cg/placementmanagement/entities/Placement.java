package com.cg.placementmanagement.entities;

import java.time.LocalDate;

public class Placement {
private long id;
private String name;
private College college;
private LocalDate date;
private String qualification;
private int year;
}
