package com.cg.placementmanagement.exceptions;

public class StudentNotFoundException extends Exception {

}
