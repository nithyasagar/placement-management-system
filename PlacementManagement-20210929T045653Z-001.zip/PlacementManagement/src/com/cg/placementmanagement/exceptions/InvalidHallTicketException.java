package com.cg.placementmanagement.exceptions;

public class InvalidHallTicketException extends Exception {

}
