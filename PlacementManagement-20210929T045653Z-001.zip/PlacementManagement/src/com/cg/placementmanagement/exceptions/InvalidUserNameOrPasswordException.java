package com.cg.placementmanagement.exceptions;

public class InvalidUserNameOrPasswordException extends Exception {

}
